public class Constants {
    public static final String WAITUPLOAD = "upload";
    public static final String WAITDOWNLOAD = "download";
    public static final String UPLOADING = "uploading";
    public static final String DOWNLOADING = "downloading";
    public static final String WAITDELETE = "delete";
    public static final String COMPLETE = "COMPLETE";
    // defines of provider
    public static final String PROVIDER_URI = "content://com.gowarrior.cloudq.CWSBucket.CWSBucketProvider/files";
    public static final String DATABASE_TABLE = "cwsbucketobjects";
    public static final String FILENAME = "fname";
    public static final String FILETYPE = "ftype";
    public static final String STATE = "state";
    public static final String CACHEDURI = "uri";
    public static final String DATE = "fdate";
    public static final String FILESIZE = "fsize";
    public static final String TRANSFERTYPE = "ttype";
    public static final String TRANSFERSIZE = "tsize";
    public static final String AUTOSIZELIMITENABLE = "enableAutoSizeLimit";
    public static final String AUTOSIZELIMITDISABLE = "disableAutoSizeLimit";
    public static final String CWSPipeService = "com.gowarrior.cloudq.CWSPipe.MqttService";
    public static final String PlatformBrand = "TigerBoard";
    public static final boolean log = false;
}
