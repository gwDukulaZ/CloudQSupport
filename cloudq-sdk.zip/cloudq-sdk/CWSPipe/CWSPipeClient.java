package com.gowarrior.cloudq.CWSPipe;

import android.content.Context;

import org.eclipse.paho.client.mqttv3.ICWSDeliveryToken;
import org.eclipse.paho.client.mqttv3.ICWSPipeToken;
import org.eclipse.paho.client.mqttv3.MqttException;

public class CWSPipeClient {
    private MqttAndroidClient mqttClient;


    /**
     * Constructor - create an CWSPipeClient that can be used to communicate with an CWS Pipe server on android
     *
     * @param context
     *            object used to pass context to the callback.
     */
    public CWSPipeClient(Context context) {
        mqttClient = new MqttAndroidClient(context, "default", null);
    }

    /**
     * Determines if this client is currently connected to the server.
     *
     * @return <code>true</code> if connected, <code>false</code> otherwise.
     */
    public boolean isConnected() {
        return mqttClient.isConnected();
    }

    /**
     * Close the client. Releases all resource associated with the client. After
     * the client has been closed it cannot be reused. For instance attempts to
     * connect will fail.
     *
     */
    public void close() {
        mqttClient.close();
        mqttClient.unregisterResources();
    }

    /**
     * Sets a callback listener to use for events that happen asynchronously.
     * <p>
     * There are a number of events that the listener will be notified about.
     * These include:
     * <ul>
     * <li>A new message has arrived and is ready to be processed</li>
     * <li>The connection to the server has been lost</li>
     * <li>Delivery of a message to the server has completed</li>
     * </ul>
     * </p>
     * <p>
     * Other events that track the progress of an individual operation such as
     * connect and subscribe can be tracked using the token returned
     * from each non-blocking method or using setting a
     * {@link CWSPipeActionListener} on the non-blocking method.
     * <p>
     *
     * @param callback
     *            which will be invoked for certain asynchronous events
     *
     * @see CWSPipeCallback
     */
    public void setCallback(CWSPipeCallback callback) {
        mqttClient.setCallback(callback);
    }

    /**
     * Connects to an CWS Pipe server using the default options.
     * <p>
     * The default options are specified in {@link CWSPipeConnectOption} class.
     * </p>
     *
     * @return token used to track and wait for the connect to complete. The
     *         token will be passed to the callback methods if a callback is
     *         set.
     * @see #connect(CWSPipeConnectOption, Object, CWSPipeActionListener)
     */
    public ICWSPipeToken connect() {
        ICWSPipeToken token = null;

        try {
            token = (ICWSPipeToken) mqttClient.connect();
        } catch (MqttException e) {
            e.printStackTrace();
        }

        return token;
    }

    /**
     * Connects to an CWS Pipe server using the specified options.
     * <p>
     * The server to connect to is specified on the constructor. It is
     * recommended to call {@link #setCallback(CWSPipeCallback)} prior to
     * connecting in order that messages destined for the client can be accepted
     * as soon as the client is connected.
     * </p>
     * <p>
     * The method returns control before the connect completes. Completion can
     * be tracked by:
     * <ul>
     * <li>Waiting on the returned token {@link ICWSPipeToken#waitForCompletion()}
     * or</li>
     * <li>Passing in a callback {@link CWSPipeActionListener}</li>
     * </ul>
     * </p>
     *
     * @param opts
     *            a set of connection parameters that override the defaults.
     * @param userContext
     *            optional object for used to pass context to the callback. Use
     *            null if not required.
     * @param listener
     *            optional listener that will be notified when the connect
     *            completes. Use null if not required.
     * @return token used to track and wait for the connect to complete. The
     *         token will be passed to any callback that has been set.
     */
    public ICWSPipeToken connect(CWSPipeConnectOption opts, Object userContext, CWSPipeActionListener listener) {
        ICWSPipeToken token = null;

        try {
            token = (ICWSPipeToken) mqttClient.connect(opts, userContext, listener);
        } catch (MqttException e) {
            e.printStackTrace();
        }

        return token;
    }

    /**
     * Disconnects from the server.
     * <p>
     * An attempt is made to quiesce the client allowing outstanding work to
     * complete before disconnecting. It will wait for a maximum of 30 seconds
     * for work to quiesce before disconnecting. This method must not be called
     * from inside {@link CWSPipeCallback} methods.
     * </p>
     *
     * @return token used to track and wait for disconnect to complete. The
     *         token will be passed to any callback that has been set.
     * @see #disconnect(long, Object, CWSPipeActionListener)
     */
    public ICWSPipeToken disconnect() {
        ICWSPipeToken token = null;

        try {
            token = (ICWSPipeToken) mqttClient.disconnect();
        } catch (MqttException e) {
            e.printStackTrace();
        }

        return token;
    }

    /**
     * Disconnects from the server.
     * <p>
     * The client will wait for {@link CWSPipeCallback} methods to complete. It
     * will then wait for up to the quiesce timeout to allow for work which has
     * already been initiated to complete. For instance when a QoS 2 message has
     * started flowing to the server but the QoS 2 flow has not completed.It
     * prevents new messages being accepted and does not send any messages that
     * have been accepted but not yet started delivery across the network to the
     * server. When work has completed or after the quiesce timeout, the client
     * will disconnect from the server. If the cleanSession flag was set to
     * false and next time it is also set to false in the connection, the
     * messages made in QoS 1 or 2 which were not previously delivered will be
     * delivered this time.
     * </p>
     * <p>
     * This method must not be called from inside {@link CWSPipeCallback} methods.
     * </p>
     * <p>
     * The method returns control before the disconnect completes. Completion
     * can be tracked by:
     * <ul>
     * <li>Waiting on the returned token {@link ICWSPipeToken#waitForCompletion()}
     * or</li>
     * <li>Passing in a callback {@link CWSPipeActionListener}</li>
     * </ul>
     * </p>
     *
     * @param quiesceTimeout
     *            the amount of time in milliseconds to allow for existing work
     *            to finish before disconnecting. A value of zero or less means
     *            the client will not quiesce.
     * @param userContext
     *            optional object used to pass context to the callback. Use null
     *            if not required.
     * @param listener
     *            optional listener that will be notified when the disconnect
     *            completes. Use null if not required.
     * @return token used to track and wait for the disconnect to complete. The
     *         token will be passed to any callback that has been set.
     */
    public ICWSPipeToken disconnect(long quiesceTimeout, Object userContext,
                             CWSPipeActionListener listener) {
        ICWSPipeToken token = null;

        try {
            token = (ICWSPipeToken) mqttClient.disconnect(quiesceTimeout, userContext, listener);
        } catch (MqttException e) {
            e.printStackTrace();
        }

        return token;
    }

    /**
     * Subscribe to default topic, which may include wildcards.
     *
     * @return token used to track and wait for the subscribe to complete. The
     *         token will be passed to callback methods if set.
     *
     * @see #subscribe(String, int, Object, CWSPipeActionListener)
     */
    public ICWSPipeToken subscribe() {
        return subscribe(null, 0, null, null);
    }

    /**
     * Subscribe to a topic, which may include wildcards.
     *
     * @param topic
     *            the topic to subscribe to, which can include wildcards.
     * @return token used to track and wait for the subscribe to complete. The
     *         token will be passed to callback methods if set.
     *
     * @see #subscribe(String, int, Object, CWSPipeActionListener)
     */
    public ICWSPipeToken subscribe(String topic) {
        return subscribe(topic, 0, null, null);
    }

    /**
     * Subscribe to a topic, which may include wildcards.
     *
     * @param topic
     *            the topic to subscribe to, which can include wildcards.
     * @param qos
     *            the maximum quality of service at which to subscribe. Messages
     *            published at a lower quality of service will be received at
     *            the published QoS. Messages published at a higher quality of
     *            service will be received using the QoS specified on the
     *            subscription.
     * @param userContext
     *            optional object used to pass context to the callback. Use null
     *            if not required.
     * @param listener
     *            optional listener that will be notified when subscribe has
     *            completed
     * @return token used to track and wait for the subscribe to complete. The
     *         token will be passed to callback methods if set.
     */
    public ICWSPipeToken subscribe(String topic, int qos, Object userContext,
                            CWSPipeActionListener listener) {
        ICWSPipeToken token = null;

        try {
            token = (ICWSPipeToken) mqttClient.subscribe(topic, qos, userContext, listener);
        } catch (MqttException e) {
            e.printStackTrace();
        }

        return token;
    }

    /**
     * Requests the server unsubscribe the client from default topic.
     *
     * @return token used to track and wait for the unsubscribe to complete. The
     *         token will be passed to callback methods if set.
     */
    public ICWSPipeToken unsubscribe() {
        ICWSPipeToken token = null;

        try {
            token = (ICWSPipeToken) mqttClient.unsubscribe((String) null);
        } catch (MqttException e) {
            e.printStackTrace();
        }

        return token;
    }

    /**
     * Requests the server unsubscribe the client from default topic.
     *
     * @param topic
     *            the topic to unsubscribe from. It must match a topic specified
     *            on an earlier subscribe.
     * @return token used to track and wait for the unsubscribe to complete. The
     *         token will be passed to callback methods if set.
     */
    public ICWSPipeToken unsubscribe(String topic) {
        ICWSPipeToken token = null;

        try {
            token = (ICWSPipeToken) mqttClient.unsubscribe(topic);
        } catch (MqttException e) {
            e.printStackTrace();
        }

        return token;
    }

    /**
     * Requests the server to unsubscribe the client from a topics.
     *
     * @param topic
     *            the topic to unsubscribe from. It must match a topic specified
     *            on an earlier subscribe.
     * @param userContext
     *            optional object used to pass context to the callback. Use null
     *            if not required.
     * @param listener
     *            optional listener that will be notified when unsubscribe has
     *            completed
     * @return token used to track and wait for the unsubscribe to complete. The
     *         token will be passed to callback methods if set.
     */
    public ICWSPipeToken unsubscribe(String topic, Object userContext,
                              CWSPipeActionListener listener) {
        ICWSPipeToken token = null;

        try {
            token = (ICWSPipeToken) mqttClient.unsubscribe(topic, userContext, listener);
        } catch (MqttException e) {
            e.printStackTrace();
        }

        return token;
    }

    /**
     * Publishes a message to default topic on the server. Takes an
     * {@link CWSPipeMessage} message and delivers it to the server at the
     * requested quality of service.
     *
     * @param message
     *            to deliver to the server
     * @return token used to track and wait for the publish to complete. The
     *         token will be passed to any callback that has been set.
     * @throws IllegalArgumentException
     *             if value of QoS is not 0, 1 or 2.
     * @see #publish(String, CWSPipeMessage, Object, CWSPipeActionListener)
     */
    public ICWSDeliveryToken publish(CWSPipeMessage message) {
        return publish(null, message, null, null);
    }

    /**
     * Publishes a message to a topic on the server.
     * <p>
     * Once this method has returned cleanly, the message has been accepted for
     * publication by the client and will be delivered on a background thread.
     * In the event the connection fails or the client stops, Messages will be
     * delivered to the requested quality of service once the connection is
     * re-established to the server on condition that:
     * <ul>
     * <li>The connection is re-established with the same clientID
     * <li>The original connection was made with (@link
     * CWSPipeConnectOption#setCleanSession(boolean)} set to false
     * <li>The connection is re-established with (@link
     * CWSPipeConnectOption#setCleanSession(boolean)} set to false
     * <li>Depending when the failure occurs QoS 0 messages may not be
     * delivered.
     * </ul>
     * </p>
     *
     * <p>
     * When building an application, the design of the topic tree should take
     * into account the following principles of topic name syntax and semantics:
     * </p>
     *
     * <ul>
     * <li>A topic must be at least one character long.</li>
     * <li>Topic names are case sensitive. For example, <em>ACCOUNTS</em> and
     * <em>Accounts</em> are two different topics.</li>
     * <li>Topic names can include the space character. For example,
     * <em>Accounts
     * 	payable</em> is a valid topic.</li>
     * <li>A leading "/" creates a distinct topic. For example,
     * <em>/finance</em> is different from <em>finance</em>. <em>/finance</em>
     * matches "+/+" and "/+", but not "+".</li>
     * <li>Do not include the null character (Unicode <samp
     * class="codeph">\x0000</samp>) in any topic.</li>
     * </ul>
     *
     * <p>
     * The following principles apply to the construction and content of a topic
     * tree:
     * </p>
     *
     * <ul>
     * <li>The length is limited to 64k but within that there are no limits to
     * the number of levels in a topic tree.</li>
     * <li>There can be any number of root nodes; that is, there can be any
     * number of topic trees.</li>
     * </ul>
     * </p>
     * <p>
     * The method returns control before the publish completes. Completion can
     * be tracked by:
     * <ul>
     * <li>Setting an {@link CWSPipeClient#setCallback(CWSPipeCallback)} where
     * the {@link CWSPipeCallback#pipeDeliveryComplete(ICWSDeliveryToken)} method will
     * be called.</li>pu
     * <li>Waiting on the returned token {@link ICWSDeliveryToken#waitForCompletion()}
     * or</li>
     * <li>Passing in a callback {@link CWSPipeActionListener} to this method</li>
     * </ul>
     * </p>
     *
     * @param topic
     *            to deliver the message to, for example "finance/stock/ibm".
     * @param message
     *            to deliver to the server
     * @param userContext
     *            optional object used to pass context to the callback. Use null
     *            if not required.
     * @param listener
     *            optional listener that will be notified when message delivery
     *            has completed to the requested quality of service
     * @return token used to track and wait for the publish to complete. The
     *         token will be passed to callback methods if set.
     * @throws IllegalArgumentException
     *             if value of QoS is not 0, 1 or 2.
     * @see CWSPipeMessage
     */
    public ICWSDeliveryToken publish(String topic, CWSPipeMessage message,
                          Object userContext, CWSPipeActionListener listener) {
        ICWSDeliveryToken token = null;

        try {
            token = (ICWSDeliveryToken) mqttClient.publish(topic, message, userContext, listener);
        } catch (MqttException e) {
            e.printStackTrace();
        }

        return token;
    }
}
